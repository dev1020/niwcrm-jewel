<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\CustomersServices */
?>
<div class="customers-services-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
