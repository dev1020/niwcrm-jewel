<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\SeatsAndChairs */

?>
<div class="seats-and-chairs-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
