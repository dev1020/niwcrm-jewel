<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\SeatsAndChairs */
?>
<div class="seats-and-chairs-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
