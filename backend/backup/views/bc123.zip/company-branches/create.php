<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\CompanyBranches */

?>
<div class="company-branches-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
