<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\PromosmsTemplates */

?>
<div class="promosms-templates-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
