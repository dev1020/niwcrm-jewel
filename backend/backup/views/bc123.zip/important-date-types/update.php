<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\ImportantDateTypes */
?>
<div class="important-date-types-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
