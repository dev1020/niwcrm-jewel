<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\ImportantDateTypes */

?>
<div class="important-date-types-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
