<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\PlaceLocations */

?>
<div class="place-locations-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
