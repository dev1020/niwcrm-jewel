<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\helpers\ArrayHelper;
use kartik\grid\GridView;

use backend\models\Customers;


return [
    
        // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'id',
    // ],
    
	[
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'order_date',
		'format' => 'raw',
		'value'=>function ($data) {
            return Html::a(ucwords($data->order_date), ['view', 'id' => $data->id],['role'=>'modal-remote','data-toggle'=>'tooltip','title'=>'Order details']);
        },
    ],
    
	[
		'attribute'=>'cust_id', 
		'width'=>'310px',
		'value'=>function ($model, $key, $index, $widget) { 
			return $model->cust->name;
		},
		'filterType'=>GridView::FILTER_SELECT2,
		'filter'=>ArrayHelper::map(Customers::find()->asArray()->all(), 'id', 'name'), 
		'filterWidgetOptions'=>[
			'pluginOptions'=>['allowClear'=>true],
		],
		'filterInputOptions'=>['placeholder'=>'Customers'],
		'group'=>false,  // enable grouping
		
	],
    [
        'class'=>'\kartik\grid\DataColumn',
        'attribute'=>'total_amount',
		'format' => 'raw',
		'value'=>function ($data) {
            return Html::a($data->total_amount, ['breakup', 'id' => $data->id],['role'=>'modal-remote','data-toggle'=>'tooltip','title'=>'Price Breakup']);
        },
    ],
    
    // [
        // 'class'=>'\kartik\grid\DataColumn',
        // 'attribute'=>'due_amount',
    // ],
    
];   