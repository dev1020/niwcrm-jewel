<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\bootstrap\Modal;
use kartik\grid\GridView;
use johnitvn\ajaxcrud\CrudAsset; 
use johnitvn\ajaxcrud\BulkButtonWidget;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\OrdersSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Orders';
$this->params['breadcrumbs'][] = $this->title;

CrudAsset::register($this);

?>

<style>
@media (max-width: 768px) {
    
	.orders-index  tbody tr td{
		height: 45px !important;
		vertical-align: middle !important;
		font-size:0.9em;
	}
	.orders-index  thead tr td,.orders-index  thead tr th,.orders-index  thead tr a{
		font-size:0.9em;
	}
	
	.order-index .select2-container{
		width:100px !important;
	}
	
	
    
}
.bg-success {
		background-color: #dff0d8 !important;
	}
.bg-warning {
    background-color: #fcf8e3 !important;
}
.orders-index tr td a {
    display: block;
    height: 100%;        
    width: 100%;
	text-decoration:underline;
	font-weight:600;
}

</style>
<div class="orders-index">
    <div id="ajaxCrudDatatable">
        <?=GridView::widget([
            'id'=>'crud-datatable',
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'pjax'=>true,
            'columns' => require(__DIR__.'/_columns.php'),
            'toolbar'=> [
                ['content'=>
                    Html::a('<i class="glyphicon glyphicon-plus"></i>', ['create'],
                    ['role'=>'modal-remote','title'=> 'Create new Orders','class'=>'btn btn-default']).
                    Html::a('<i class="glyphicon glyphicon-repeat"></i>', [''],
                    ['data-pjax'=>1, 'class'=>'btn btn-default', 'title'=>'Reset Grid']).
                    '{toggleData}'.
                    '{export}'
                ],
            ],          
            'striped' => true,
            'condensed' => true,
            'responsive' => true, 
			'responsiveWrap'=>false,			
            'panel' => [
                'type' => 'primary', 
                'heading' => '<i class="glyphicon glyphicon-list"></i> Orders listing',
                'before'=>'<em>* Resize table columns just like a spreadsheet by dragging the column edges.</em>',
                'after'=>false,
            ],
			'rowOptions' => function ($model, $index, $widget, $grid){
			  if($model->status == 'isdue'){
				 return ['class'=>'bg-warning'];
			 }
			 if($model->status == 'completed'){
				 return ['class'=>'bg-success'];
			 }
			 
			 },
        ])?>
    </div>
</div>
<?php $js = <<<SCRIPT
/* To initialize BS3 tooltips set this below */
$(function () { 
    $("[data-toggle='tooltip']").tooltip(); 
});;
SCRIPT;
// Register tooltip/popover initialization javascript
$this->registerJs($js);
?>
<?php Modal::begin([
    "id"=>"ajaxCrudModal",
    "footer"=>"",// always need it for jquery plugin
])?>
<?php Modal::end(); ?>
