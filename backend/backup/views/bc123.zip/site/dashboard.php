<?php
	use yii\helpers\Html;
	use yii\helpers\Url;
	use yii\widgets\Pjax;
	use miloschuman\highcharts\Highcharts;
/* @var $this yii\web\View */

$this->title = yii::$app->name.' Dashboard.';
?>
 <style> 
.quicklinks .btn {
	text-transform:Capitalize;
	font-size: 1em;
} 
body *{
  
}
 </style>  
			<div class="row">
			<hr>
				<div class="col-lg-4 col-xs-12 col-md-12 col-sm-12quicklinks">
					<div class="box box-warning">
						<div class="box-header">
						  <h3 class="box-title">Quick Links</h3>
						</div>
						<div class="box-body">
						  <a href="<?= Url::toRoute(['/customers/index'])?>" class="btn btn-warning btn-block btn-lg">Manage Customers</a>
						  <a href="<?= Url::toRoute(['/station/index'])?>" class="btn btn-info btn-block btn-lg">ADD/Open Sales</a>
						  <a href="<?= Url::toRoute(['/orders/index'])?>" class="btn btn-success btn-block btn-lg">View Order Details</a>                 
						  <a href="<?= Url::toRoute(['/services/ratecard'])?>" class="btn btn-danger btn-block btn-lg">Rate/Menu Card</a>
						 
						</div>
					</div>
				</div>
				<div class="col-lg-8 col-xs-12 col-md-12 col-sm-12">

					
<?= Highcharts::widget([
   'options' => [
		'credits'=> [ 'enabled'=> false],
		'title' => ['text' => 'SALES FIGURE'],
		'xAxis' => [
			'categories' => ['Jan', 'Feb', 'Mar', 'Apr']
		],
		
	  
	'series' => [
	 ['type'=> 'column','name' => 'Dev', 'data' => [1, 1, 4, 2]],
	 ['type'=> 'column','name' => 'Ria', 'data' => [5, 7, 3, 7]],
	 ['type'=> 'column','name' => 'Sri', 'data' => [4, 5, 5, 120]],
	 ['type'=> 'column','name' => 'Srwwi', 'data' => [2, 2, 4, 5]],
	 ['type'=> 'column','name' => 'Srwwi3', 'data' => [2, 2, 4, 5]],
	 ['type'=> 'column','name' => 'Srwwi4', 'data' => [2, 2, 4, 5]],
	 
	 
	]
   ]
]);
?>

					
					    

					





				
				</div>
			</div>
			