<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\ResetPasswordForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Modal;
use johnitvn\ajaxcrud\CrudAsset; 

$this->title = 'Settings';
$this->params['breadcrumbs'][] = $this->title;

CrudAsset::register($this);
?>
<div class="site-reset-password">
	<div class="container">
		
		<div class="row">
			<div class="col-lg-10">
				
				<?php $form = ActiveForm::begin(['id' => 'reset-password-form','options'=>['class'=>'form-horizontal','enctype'=>'multipart/form-data']]); ?>

					<?= $output ?>
					<hr style="border-top: 2px solid #6f4b4b;">
					<div class="col-md-offset-4 col-md-4">
						<div class="form-group text-center">
							<?= Html::submitButton('Save', ['class' =>'btn btn-success btn-block']) ?>
						</div>
					</div>
				<?php ActiveForm::end(); ?>
			</div>
			<div class="col-lg-2">
			
				<?= Html::a('<i class="glyphicon glyphicon-plus"></i> Add Setings Attribute', ['settings-add-attributes'],
                    ['role'=>'modal-remote','title'=> 'Add new Attributes','class'=>'btn btn-success'])?>
			</div>
		</div>
	</div>
</div>


<?php Modal::begin([
    "id"=>"ajaxCrudModal",
    "footer"=>"",// always need it for jquery plugin
])?>
<?php Modal::end(); ?>