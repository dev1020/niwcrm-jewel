<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\CustomersLog */
?>
<div class="customers-log-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
