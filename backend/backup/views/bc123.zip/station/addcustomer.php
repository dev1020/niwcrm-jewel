<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\web\JsExpression;
use backend\models\Customers;
use yii\jui\AutoComplete;


/* @var $this yii\web\View */
/* @var $model backend\models\Customers */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
  .ui-autocomplete {
    max-height: 100px;
    overflow-y: auto;
    /* prevent horizontal scrollbar */
    overflow-x: hidden;
  }
  /* IE 6 doesn't support max-height
   * we use height instead, but this forces the menu to always be this tall
   */
  * html .ui-autocomplete {
    height: 100px;
  }
</style>

<div class="customers-form">
<?php 
	$data = Customers::find()
    ->select(['concat("C",id) as value', 'concat("C",id) as  label','name','gender'])
    ->asArray()
    ->all();

 ?>
    <?php $form = ActiveForm::begin(['id' => 'cust-form',]); ?>
		<div class="alert alert-error error">
  
		</div>
	
	<?= $form->field($model, 'other')->widget(\yii\jui\AutoComplete::classname(), [
    
    'clientOptions' => [
		'appendTo'=>'#cust-form',
        'source' => $data, 
		'max'=>10,
        'autoFill'=>true,
         'select' => new JsExpression("function( event, ui ) {
        $('#customers-name').val(ui.item.name);
        $('#customers-gender').val(ui.item.gender);
     }")
	 ],
	 'options' => ['class' =>'form-control'],
     ])->label('Contact For New / Id For Existing') ?>
	 <!--//$form->field($model, 'contact')->textInput(['maxlength' => true,'onkeyup'=>'findcustomer(this.value)']) -->
	
    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    

	<?= $form->field($model, 'gender')->dropDownList([ 'female' => 'Female', 'male' => 'Male', ]) ?>
	<div class="form-group">
	<label>Type</label>
	<?= Html::dropDownList('type', null,['salon'=>'salon','home'=>'home'],['class'=>'form-control']) ?>
	</div>
	<div class="form-group">
		<?= Html::submitButton('Start', ['class' => 'btn btn-primary btn-block', 'name' => 'login-button','id'=>'loginsubmit']) ?>
	</div>
	

    <?php ActiveForm::end(); ?>
    
</div>

<?php 
$servicesurl = Url::to(['station/customer-services']);
$billsurl = Url::to(['station/generate-bill']);

$script = <<< JS
$('.error').hide();

$('form#cust-form').on('beforeSubmit',function(e){
	$('.error').hide();
	var form = $(this);
	$.post(
		form.attr("action"),
		form.serialize()
	)
	.done(function(result){
		if(result.entrystatus){
			var labeltype='';
			if(result.type=='salon'){
				labeltype = 'success';
			}else{
				labeltype = 'primary';
			}
			$('#ajaxCrudModal').modal('hide');
			var customer = '<div class="customer col-lg-12 col-xs-12 custdet'+result.id+'" >';							
			customer = customer + '<a href="$servicesurl?id='+result.id+'&cust_session='+result.session_no+'" data-id="'+result.id+'"><div class="col-lg-3 col-xs-3 text-center"><img src="'+result.image+'" style="max-height:50px"></div>';
			customer = customer + '<div class="col-lg-6 col-xs-6 text-center bg-info" style="min-height:54px"><h5 class=""><sup class="pull-left"><span class="label bg-navy">'+result.session_no+'</span></sup>'+result.name+'</h5></div></a>'; 
			customer = customer + '<div class="col-lg-3 col-xs-3 text-center" style="padding:2px"><a href="$billsurl?id='+result.id+'&session_no='+result.session_no+'" class="btn btn-block bg-purple bill" ><i class="fa fa-file-text"></i> BILL</a></div>';
			customer = customer + '<div class="ribbon"><span class="'+labeltype+'">'+result.type+'</span></div></div>';
			
			newcustomer = $(customer).hide();
			$('.customersplace').append(newcustomer);
			$('.footer').focus();
			newcustomer.show("bounce", { times: 3 }, "slow");
		}
		if(result.error){
			$('.error').show();
			$('.error').html(result.error);
		}
	});
	
	return false;
});
JS;
$this->registerJs($script);
?>
