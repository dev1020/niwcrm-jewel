<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\models\Categories;
use yii\web\JsExpression;


use kartik\depdrop\DepDrop;

/* @var $this yii\web\View */
/* @var $model backend\models\Customers */
/* @var $form yii\widgets\ActiveForm */


?>
<style>
.modal-header{
	display:none;
}
.bg-primary {
    color: #fff;
    background-color: #337ab7 !important;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
   
    vertical-align: middle;
	cursor:pointer;
    
}
.catbutton{
	width: 80px;
height: 80px;
background-size:100% 100%;
background-repeat: no-repeat;
border:1px solid #F05199;
border-radius:10px;
margin:5px;
}
.subcategory .catimage{
	height:60px;
	text-align:center;
}
.subcategory .cattext{
	height:60px;
	text-align:center;
	
}

</style>
<?php
// Templating example of formatting each list element
$url = \Yii::$app->urlManager->baseUrl . '/images/flags/';

?>
<div class="customers-form">
<?php $categories = Categories::find()->where(['category_root'=>0])->all();?>


    <div class="row">
	<?php $form = ActiveForm::begin(['options'=>['id'=>'assign-form']]); ?>
		<div class="col-lg-6  no-gutter">
			
			<div class="col-lg-12">
					<?= $form->field($model, 'customer_id')->hiddenInput(['value'=> $customer->id])->label(false);?>
					<?= $form->field($model, 'cust_session')->hiddenInput(['value'=> $cust_session])->label(false);?>
					
					<?= $form->field($model, 'category')->hiddenInput(['value'=> '','id'=>'catid','class'=>'form-control'])->label(false);?>
					<div class="categories text-center" style="margin-bottom:20px">
						<h4>Categories</h4>
					<?php foreach($categories as $category){?>
						
						<span class="btn btn-sm btn-warning catbutton " style="background-image:Url(<?= Yii::getAlias('@frontendimage').'/categorypic/'. $category->category_pic?>)" data-catid="<?= $category->category_id ?>" onclick="dosome(this)"></span>
					<?php }?>
					</div>
					<?= $form->field($model, 'subCategory')->widget(DepDrop::classname(), [
	//'data'=> [6=>'Bank'],
	'options' => ['id'=>'subcatid','placeholder' => 'Select ...','onchange' => '$.post( "'. Url::toRoute('/station/services') .'", { catid:$("#catid").val() , subcatid: $(this).val(),cust_session:$("#servicestocustomerselectionform-cust_session").val(),custid:$("#servicestocustomerselectionform-customer_id").val()})
	.done(function(res){$("#servicesdata").html(res.output);});'],
	'type' => DepDrop::TYPE_SELECT2,
	'select2Options'=>[
		'pluginOptions'=>[
			'allowClear'=>true,
			//'escapeMarkup' => new JsExpression('function (markup) { return markup; }'),
			//'templateResult' => new JsExpression('formatRepo'),
			//'templateSelection' => new JsExpression('formatRepoSelection'),
		],
		'hideSearch'=>true,
		
	],
	'pluginOptions'=>[
		'depends'=>['catid'],
		'placeholder'=>'Select...',
		'url'=>Url::to(['/station/subcat']),
		'dataType' => 'json',
	]
]);?>
					
							
			</div>
			
		</div>
		<div class="col-lg-6  no-gutter">
			<div class="col-lg-12">
				<div id="servicesdata">
				</div>
			</div>
			
		</div>
		
		
		<?php ActiveForm::end(); ?>
	</div>
	
</div>
<?php 
$addserviceurl = Url::to(['station/add-services']);
$subcaturl = Url::to(['station/subcat']);
$script = <<< JS
function dosome(e){
	var id = e.getAttribute("data-catid");
	$('#catid').val(id);
	$("#catid").trigger("change");
}
function getservice(e){
	var servicesid = e.getAttribute("data-id");
	if(e.getAttribute("class")=='bg-success'){
		e.classList.remove("bg-success");
		document.getElementById("services"+servicesid).value = "";
	}else{
		e.classList.add("bg-success");
		document.getElementById("services"+servicesid).value = servicesid;
	}
	
	
	//alert(servicesvalue);
}


$('form#assign-form').on('beforeSubmit',function(e){
	var form = $(this);
	  $.post(
		"$addserviceurl",
		form.serialize()
	)
	.done(function(result){
		for(var i = 0; i < result.length; i++) {
			var obj = result[i];
			$("#servicetr"+obj.id).removeAttr("onclick");
			$("#imgtd"+obj.id).append('<i class="fa fa-check pull-left text-success" style="margin-top: 10px;"></i>');
			$("#services"+obj.id).remove();
		}
	});
	return false;
});


JS;
$this->registerJs($script);
?>
