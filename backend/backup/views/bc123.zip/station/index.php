<?php
use yii\helpers\Url;
use yii\helpers\Html;
use yii\bootstrap\Modal;


/* @var $this yii\web\View */
/* @var $searchModel backend\models\CategoriesSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::$app->name.' '.' Station';
$this->params['breadcrumbs'][] = $this->title;

?>
<style>
.seats{
	width:24%;
	margin:1%;
	position:relative;
	float:left;
	height:100px;
	border-width:5px;  
    border-style:double;
	border-color:#F05199;
	
}
.customer{
	cursor:pointer;
	border:2px solid #F07851;
	background:#fff;
	text-transform:capitalize;
	border-radius:5px;
	margin-top:5px;
	
}
.bill{
	min-height: 52px;
    font-size: 1.2em;
    line-height: 35px;
}
sup{
	font-size:100%;
	letter-spacing: 1px;
}


.ribbon {
  position: absolute;
  left: -5px; top: -5px;
  z-index: 1;
  overflow: hidden;
  width: 75px; height: 75px;
  text-align: right;
}
.ribbon span {
    font-size: 10px;
    font-weight: bold;
    color: #FFF;
    text-transform: uppercase;
    text-align: center;
    line-height: 20px;
    transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);
    width: 80px;
    display: block;
    box-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);
    position: absolute;
    top: 10px;
	left: -20px;
}
.ribbon span::before {
  content: "";
  position: absolute; left: 0px; top: 100%;
  z-index: -1;
  border-left: 3px solid #1e5799;
  border-right: 3px solid transparent;
  border-bottom: 3px solid transparent;
  border-top: 3px solid #1e5799;
}
.ribbon span::after {
  content: "";
  position: absolute; right: 0px; top: 100%;
  z-index: -1;
  border-left: 3px solid transparent;
  border-right: 3px solid #1e5799;
  border-bottom: 3px solid transparent;
  border-top: 3px solid #1e5799;
}
.ribbon .primary{
	background: #79A70A;
    background: linear-gradient(#2989d8 0%, #1e5799 100%);
}
.ribbon .success{
	background: #79A70A;
	background: linear-gradient(#9BC90D 0%, #79A70A 100%);
}

</style>
<div class="station-index">
    <div class="row">
		<div class="col-lg-9">
			
			<div class="col-lg-12 no-gutter">
				<div class="col-lg-3" style="margin-bottom:10px">
					<?= Html::a('<i class="glyphicon glyphicon-plus text-success"></i> New Sale', ['add-customer'],['role'=>'modal-remote','title'=> 'Add Customers','data-toggle'=>'tooltip','class'=>'btn btn-lg btn-default' ,'style'=>'border-radius:25px;border:2px solid #F07851']) ?>
				</div>
				<div class="col-lg-9  customersplace">
					<?php foreach($customers_now as $customer){?>
					
						<div class="customer col-lg-12 col-xs-12 custdet<?= $customer->session_no ?>" >
							
							<a class="custa" href="<?= Url::to(['station/customer-services','id'=>$customer->cust->id,'cust_session'=>$customer->session_no])?>" data-id="<?= $customer->cust->id ?>">
								<div class="col-lg-3 col-xs-3 text-center">
								<?php if($customer->cust->gender == 'female'){
									echo '<img src="'.Url::to('@frontendimage'.'/new-female.png').'" style="max-height:50px">';
								}else{
									echo '<img src="'.Url::to('@frontendimage'.'/new-male.png').'" style="max-height:50px">';
								}?>
								
								</div>
								<div class="col-lg-6 col-xs-6 text-center bg-info" style=" min-height:54px">
									<h5 class=""><sup class="pull-left"><span class="label bg-navy"><?= $customer->session_no ?></span></sup> &nbsp;<?= $customer->cust->name ?> </h5>
									
								</div>
							</a>
							
							<div class="col-lg-3 col-xs-3 text-center" style="padding:2px">
								<a  href="<?= Url::to(['station/generate-bill','id'=>$customer->cust->id,'session_no'=>$customer->session_no])?>" class="btn bg-purple btn-block bill"><i class="fa fa-file-text"></i> BILL</a>
							</div>
								
							<div class="ribbon"><span class="<?= ($customer->type=='salon')? 'success':'primary' ?>"><?= $customer->type ?></span></div>
						</div>
					<?php }?>
					
				</div>
			</div>
		</div>
	</div>
</div>

<?php $script = <<< JS
	$(function(){
		
		/*$(document).on('click','.customer > a',function(){
			var custid = $(this).attr('data-id');
			alert(custid);
		});*/
		
		
		
	});
	
JS;
$this->registerJs($script);
?>
<?php Modal::begin([
    "id"=>"ajaxCrudModal",
	 "size"=>"modal-lg",
    "footer"=>"",// always need it for jquery plugin
])?>
<?php Modal::end(); ?>
