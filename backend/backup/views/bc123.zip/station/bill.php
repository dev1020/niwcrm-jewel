<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Customers */
/* @var $form yii\widgets\ActiveForm */


$this->title = 'Customer Bill';
$this->params['breadcrumbs'][] = ['label' => 'Station', 'url' => ['station/index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.modal-header{
	display:none;
}
.modal-body{
	border-radius:2px;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
   
    vertical-align: middle;
	padding: 5px;
    
}

</style>
<div class="customers-form" style="background:#ffffff;padding:5px">
		<?php if (!Yii::$app->request->isAjax){ 
			if(isset($generatebill)){
				echo '<div class="alert alert-success text-center">'.$msg.'</div>';
			}
			
		 } ?>
	
		<h2 class="text-center" style="margin:0px"><?php if($customer->gender == 'female'){
			echo '<img src="'.Url::to('@frontendimage'.'/new-female.png').'" style="max-height:50px;">';
		}else{
			echo '<img src="'.Url::to('@frontendimage'.'/new-male.png').'" style="max-height:50px;">';
		}?>&nbsp;&nbsp;<span class="text-primary"><?= ucfirst($customer->name) ?></span></h2>
		
		<hr>
	
	<?php $form = ActiveForm::begin(['options'=>['id'=>'bill-form']]); ?>
	
		<div class="col-lg-12">
			<table class="table table-bordered servicestable">
				<tr class="bg-primary">
					<th class="text-center">Image</th>
					<th class="text-center">Service Name</th>
					
					<th class="text-center" width="30%">Price </th>
					
				</tr>
				<tbody>
					<?php if(!count($cust_sessionsdata)>0){
						echo '<tr><td colspan="3" class="text-center"><h3>No services found. Please Add Services </h3></td></tr>';
					}else{
						foreach($cust_sessionsdata as $key=>$servicesall){
							echo '<tr ><td class="bg-success" colspan="3"><strong>SALE NO -'.$key.'</strong></td></tr>';
							foreach($servicesall as $services){
					?>
					<!--<tr>
						<td class="tg-0pky"></td>
						<td class="tg-0pky"></td>
						<td class="tg-0pky" rowspan="2"><br>ssss<br>s<br>s<br>s<br></td>
					  </tr>-->
					  
					<tr>
						<td class="text-center "><img src="<?= Url::to('@frontendimage'.'/services/'.$services->service->services_icon)?>" style="max-height:40px;"></td>
						<td class="text-center"><?= $services->service->name ?></td>
						
						<td class="text-center"><input type="tel" onClick="this.select()" class="form-control prices numeric" id="services<?=$services->service->id ?>" data-max="<?=$services->service->price_max?>" data-min="<?=$services->service->price?>" data-servicename="<?= ucwords($services->service->name) ?>" data-fixedprice="<?=$services->service->fixedprice?>" value ="<?= (int)$services->service->price ?>" name="<?= $key?>[<?= $services->service->id ?>]"></td>
						
						
						
					</tr>
					<?php } } }?>
				</tbody>
			</table>
		</div>
		<?php if (!Yii::$app->request->isAjax){ ?>
			<div class="form-group text-center">
				<?= Html::submitButton('GENERATE BILL', ['class' => 'btn btn-success']) ?>
			</div>
		<?php } ?>
	
    <?php ActiveForm::end(); ?>
    
</div>
<?php $scripts = <<< JS
$(function(){
	var check = 'true';
	$('.prices').on('blur',function(){
		if(check=='true'){
			element = $(this);
			checkprice(element);
		}
	});
	function checkprice(e){
		check = 'false';
		var index = $( ".prices" ).index(e);
		//console.log(index);
		var id = e.attr('id'); 
		var servicename = e.attr('data-servicename'); 
		var fixedprice = e.attr('data-fixedprice'); 
		var maxprice = parseInt(e.attr('data-max')); 
		var minprice = parseInt(e.attr('data-min')); 
		var value = parseInt(e.val()); 
		//console.log('maxprice-'+maxprice+',minprice-'+minprice+',value-'+value);
		//console.log(check);
		if(fixedprice=='no'){
			if(value>maxprice){
			
				$.confirm({
					title: '<h3 class="text-danger">Please Confirm</h3>',
					content: 'Max Price of <b>'+servicename+'</b> is <b>Rs.'+maxprice+'</b>. Click <b>Ok</b> To go with this Price. Click <b>Cancel</b> to reset price.',
					icon: 'fa fa-exclamation-circle',
					animation: 'scale',
					closeAnimation: 'scale',
					opacity: 0.5,
					buttons: {
						'confirm': {
							text: 'Ok',
							btnClass: 'btn-danger ',
							action: function(){
								check = 'true';
								$( ".prices" ).eq(index + 1).focus();
							}
						},
						cancel: function(){
							$('#'+id).val(maxprice);
							check = 'true';
							$( ".prices" ).eq(index + 1).focus();
						},
						
					}
				});
			}else if(value<minprice){
				
				$.confirm({
					title: '<h3 class="text-danger">Please Confirm</h3>',
					content: 'Min Price of <b class="text-info">'+servicename+'</b> is <b class="text-success">Rs.'+minprice+'</b>. Click <b>Ok</b> To go with this Price. Click <b>Cancel</b> to reset price.',
					icon: 'fa fa-exclamation-circle',
					animation: 'scale',
					closeAnimation: 'scale',
					opacity: 0.5,
					buttons: {
						'confirm':{
							text: 'Ok',
							btnClass: 'btn-danger',
							action: function(){
								check = 'true';
								$( ".prices" ).eq(index + 1).focus();
							}
						},
						cancel: function(){
							$('#'+id).val(minprice);
							check = 'true';
							$( ".prices" ).eq(index + 1).focus();
						},
					}
				});
				
			}
		}else if(fixedprice=='yes'){
			
			$.confirm({
				title: '<h3 class="text-danger">Please Confirm</h3>',
				content: 'Fixed Price of <b class="text-info">'+servicename+'</b> is <b class="text-success">Rs.'+minprice+'</b>. Click <b>Ok</b> To go with this Price. Click <b>Cancel</b> to reset price.',
				icon: 'fa fa-exclamation-circle',
				animation: 'scale',
				closeAnimation: 'scale',
				opacity: 0.5,
				buttons: {
					'confirm':{
						text: 'Ok',
						btnClass: 'btn-danger',
						action: function(){
							check = 'true';
							$( ".prices" ).eq(index + 1).focus();
						}
					},
					cancel: function(){
						$('#'+id).val(minprice);
						check = 'true';
						$( ".prices" ).eq(index + 1).focus();
					},
				}
			});
		}
	}
	
});



JS;

$this->registerJs($scripts);
?>

