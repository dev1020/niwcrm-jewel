<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\bootstrap\Modal;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $model backend\models\Customers */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Customer Services';
$this->params['breadcrumbs'][] = ['label' => 'Station', 'url' => ['station/index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.modal-header{
	background:#E08E0B;
	color:#fff;
}
.modal-body{
	border-radius:2px;
}
.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
   
    vertical-align: middle;
	padding: 5px;
    
}

</style>

<div class="customers-form" style="background:#ffffff;padding:5px">
	
		<h2 class="text-center" style="margin:0px"><?php if($customer->gender == 'female'){
			echo '<img src="'.Url::to('@frontendimage'.'/new-female.png').'" style="max-height:50px;">';
		}else{
			echo '<img src="'.Url::to('@frontendimage'.'/new-male.png').'" style="max-height:50px;">';
		}?>&nbsp;&nbsp;<span class="text-primary"><?= ucfirst($customer->name) ?></span>
		<?php if (!Yii::$app->request->isAjax){ 
				if($billgenerated){
					echo Html::a('<i class="fa fa-trash"></i> Delete Sale', ['/station/close-session','id'=>$customer->id,'cust_session'=>$cust_session,'mode'=>'delete'], ['class' => 'btn btn-danger pull-right','style'=>'margin-left:20px','role'=>'modal-remote','title'=>'Delete', 
                          'data-confirm'=>false, 'data-method'=>false,// for overide yii data api
                          'data-request-method'=>'post',
                          'data-toggle'=>'tooltip',
                          'data-confirm-title'=>'Are you sure?',
                          'data-confirm-message'=>'Are you sure want to Delete this session',]);
				}else{
					echo Html::a('<i class="fa fa-times"></i> Close Sale', ['/station/close-session','id'=>$customer->id,'cust_session'=>$cust_session,'mode'=>'close'], ['class' => 'btn btn-danger pull-right','style'=>'margin-left:20px','role'=>'modal-remote','title'=>'Close', 
                          'data-confirm'=>false, 'data-method'=>false,// for overide yii data api
                          'data-request-method'=>'post',
                          'data-toggle'=>'tooltip',
                          'data-confirm-title'=>'Are you sure?',
                          'data-confirm-message'=>'Are you sure want to close this session',]);
				}
				
			 } ?>
		
		
		</h2>
		
		<hr>
	
	
	<div class="row">
		<div class="col-lg-12">
		<?php Pjax::begin(['options'=>['id'=>'customers-services-table','data-pjax-container'=>'customers-services-table']]);?>
			<table class="table table-bordered servicestable">
				<tr class="bg-primary">
					<th class="text-center">Image</th>
					<th class="text-center">Service Name</th>
					<th class="text-center">Tech</th>
					<th class="text-center">Act</th>
				</tr>
				<tbody>
					<?php if(!count($customerservices)>0){
						echo '<tr><td colspan="4" class="text-center"><h3>No services found. Please Add Services </h3></td></tr>';
					}else{
						foreach($customerservices as $services){
					?>
					
					<tr>
						<td class="text-center "><i class="fa fa-circle text-danger pull-left"></i><img src="<?= Url::to('@frontendimage'.'/services/'.$services->service->services_icon)?>" style="max-height:40px;max-width:40px;"></td>
						<td class="text-center"><label class="label label-primary"><?= ucwords($services->service->category->category_name) ?></label><br><?= $services->service->name ?></td>
						<td class="text-center"><?= Html::a('<i class="fa fa-user"></i>',['station/assign-services','id'=>$services->id,'cust_id'=>$customer->id,'cust_session'=>$cust_session],['class'=>'btn btn-info','data-id'=>$services->id,'role'=>'modal-remote','title'=>'Assign Service'])?>
						 </td>
						
						<td class="text-center">
							
							<?= Html::a('<i class="fa fa-times"></i>',['station/delete-services','id'=>$services->id,'cust_id'=>$customer->id,'cust_session'=>$cust_session],['class'=>'btn btn-danger','data-id'=>$services->id,'role'=>'modal-remote','title'=>'Delete', 
                          'data-confirm'=>false, 'data-method'=>false,// for overide yii data api
                          'data-request-method'=>'post',
                          'data-toggle'=>'tooltip',
                          'data-confirm-title'=>'Are you sure?',
                          'data-confirm-message'=>'Are you sure want to delete this item',])?>
						   </td>
					</tr>
					<?php } } ?>
				</tbody>
			</table>
			<?php Pjax::end();?>
			<?php if (!Yii::$app->request->isAjax){ 
				if($billgenerated){
					echo '<div class="form-group text-center">'.Html::a('Add Services', ['/station/add-services-to-customer','id'=>$customer->id,'cust_session'=>$cust_session], ['class' => 'btn btn-success','data-pjax'=>0,]).\yii\helpers\Html::a('<i class="fa fa-file-text"></i> BILL', ['station/generate-bill','id'=>$customer->id,'session_no'=>$cust_session], ['class' => 'btn bg-purple ','style'=>'margin-left:20px']).'</div>';
				}else{
					echo '<div class="form-group text-center">'.Html::button('Bill already Generated', ['class' => 'btn btn-danger','disabled'=>'disabled']).Html::a(' &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-inr"></i> Pay&nbsp;&nbsp;&nbsp;&nbsp; ',['/station/order-payment','orderid'=>1],['class'=>'btn btn-success','style'=>'margin-left:20px']).'</div>';
				}
				
			 } ?>
		</div>
	</div>
    
    
</div>

<?php Modal::begin([
    "id"=>"ajaxCrudModal",
	 "size"=>"modal-lg",
    "footer"=>"",// always need it for jquery plugin
])?>
<?php Modal::end(); ?>

