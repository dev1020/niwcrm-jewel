<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Services */
?>
<div class="services-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
