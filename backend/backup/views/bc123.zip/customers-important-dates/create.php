<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\CustomersImportantDates */

?>
<div class="customers-important-dates-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
