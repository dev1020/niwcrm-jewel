<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\CustomersImportantDates */
?>
<div class="customers-important-dates-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
