<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Customers */

?>
<div class="customers-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
