<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Bposts */

?>
<div class="bposts-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
