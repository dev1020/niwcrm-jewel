<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Coupons */
?>
<div class="coupons-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
